#include <stdio.h>
#include "sub.h"

void sub_fun(void)
{
    printf("Sub fun,  A = %d!\n", A);   
}
