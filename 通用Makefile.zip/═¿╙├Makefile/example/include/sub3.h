
#define C  3
void sub3_fun(void); 

