#define A  1
void sub_fun(void); 
