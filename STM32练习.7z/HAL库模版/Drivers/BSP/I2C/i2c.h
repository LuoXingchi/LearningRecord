#ifndef _I2C_H
#define _I2C_H
#include "./SYSTEM/sys/sys.h"

/******************************************************************************************/
/* ���� ���� */

#define IIC_SCL_GPIO_PORT               GPIOB
#define IIC_SCL_GPIO_PIN                GPIO_PIN_6
#define IIC_SCL_GPIO_CLK_ENABLE()       do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* PB��ʱ��ʹ�� */

#define IIC_SDA_GPIO_PORT               GPIOB
#define IIC_SDA_GPIO_PIN                GPIO_PIN_7
#define IIC_SDA_GPIO_CLK_ENABLE()       do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* PB��ʱ��ʹ�� */

/***********************************Ӳ��I2Cʹ��********************************************/

#define IIC1_CLK_ENABLE()				do{ __HAL_RCC_I2C1_CLK_ENABLE(); }while(0)	  /* I2C����ʱ��ʹ�� */


/***********************************����I2Cʹ��********************************************/
/* IO���� */
#define IIC_SCL(x)        do{ x ? \
                              HAL_GPIO_WritePin(IIC_SCL_GPIO_PORT, IIC_SCL_GPIO_PIN, GPIO_PIN_SET) : \
                              HAL_GPIO_WritePin(IIC_SCL_GPIO_PORT, IIC_SCL_GPIO_PIN, GPIO_PIN_RESET); \
                          }while(0)       /* SCL */

#define IIC_SDA(x)        do{ x ? \
                              HAL_GPIO_WritePin(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN, GPIO_PIN_SET) : \
                              HAL_GPIO_WritePin(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN, GPIO_PIN_RESET); \
                          }while(0)       /* SDA */

#define IIC_READ_SDA     HAL_GPIO_ReadPin(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN) /* ��ȡSDA */

#define IIC_READ_SDA     HAL_GPIO_ReadPin(IIC_SDA_GPIO_PORT, IIC_SDA_GPIO_PIN) /* ��ȡSDA */
/******************************************************************************************/
/* �ⲿ�ӿں���*/

void i2c_init(void);					/* I2C��ʼ�� */
void iic_start(void);					/* I2C��ʼ�ź� */
void iic_stop(void);					/* I2C�����ź� */
void iic_ack(void);						/* Ӧ���ź� */
void iic_nack(void);					/* ��Ӧ���ź� */
uint8_t iic_wait_ack(void);				/* �ȴ��ӻ�Ӧ�� */
void iic_send_byte(uint8_t data);		/* ����1�ֽ����� */
uint8_t iic_read_byte(uint8_t ack);		/* ��ȡ1�ֽ����� */

#endif
