#ifndef _ADC_H
#define _ADC_H
#include "./SYSTEM/sys/sys.h"


/******************************************************************************************/
/* ���Ŷ��� */

#define ADC1_CH3_GPIO_PORT                  	GPIOA
#define ADC1_CH3_GPIO_PIN                   	GPIO_PIN_3
#define ADC1_CH3_GPIO_CLK_ENABLE()          	do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)
#define ADC1_CH3                        		ADC_CHANNEL_3

#define ADC1_CH4_GPIO_PORT                  	GPIOA
#define ADC1_CH4_GPIO_PIN                   	GPIO_PIN_4
#define ADC1_CH4_GPIO_CLK_ENABLE()          	do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)
#define ADC1_CH4                        		ADC_CHANNEL_4

#define ADC1_CH5_GPIO_PORT                  	GPIOA
#define ADC1_CH5_GPIO_PIN                   	GPIO_PIN_5
#define ADC1_CH5_GPIO_CLK_ENABLE()          	do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)
#define ADC1_CH5                        		ADC_CHANNEL_5

#define ADC1_CH6_GPIO_PORT                  	GPIOA
#define ADC1_CH6_GPIO_PIN                   	GPIO_PIN_6
#define ADC1_CH6_GPIO_CLK_ENABLE()          	do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)
#define ADC1_CH6                        		ADC_CHANNEL_6

#define ADC1_CHY_CLK_ENABLE()           	    do{ __HAL_RCC_ADC1_CLK_ENABLE(); }while(0)

/* ע�⣺STM32F103C8T6оƬֻ��DMA1����ADC1��DMAͨ��ֻ��ΪDMA1_Channel1��ADC2��֧��DMA�ɼ� */
#define ADC1_DMA1_CH1				   			DMA1_Channel1
#define ADC1_DMA1_IRQn                 			DMA1_Channel1_IRQn
#define ADC1_DMA1_IRQHandler           			DMA1_Channel1_IRQHandler


/******************************************************************************************/
/* �ⲿ�ӿں���*/
void adc_dma_init(uint32_t mar);			/* ��ͨ��ADC1+DMA��ʼ�� */
void adc_nch_dma_init(uint32_t mar);		/* ��ͨ��ADC1+DMA��ʼ�� */
void dma_enable(uint16_t count);			/* ����DMA1 */
void ADC1_DMA_Test(void);					/* ��ͨ��ADC1+DMA����   */
void ADC1_NCH_DMA_Test(void);				/* ��ͨ��ADC1+DMA����   */

#endif
