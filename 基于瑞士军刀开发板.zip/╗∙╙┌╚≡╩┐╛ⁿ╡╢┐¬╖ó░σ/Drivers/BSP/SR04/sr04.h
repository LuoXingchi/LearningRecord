#ifndef _SR04_H
#define _SR03_H
#include "./SYSTEM/sys/sys.h"


/******************************************************************************************/
/* ���Ŷ��� */

#define SR04_ECH0_GPIO_PORT                  GPIOB
#define SR04_ECH0_GPIO_PIN                   GPIO_PIN_8
#define SR04_ECH0_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)  /* PB��ʱ��ʹ�� */

#define SR04_TRIG_GPIO_PORT                  GPIOB
#define SR04_TRIG_GPIO_PIN                   GPIO_PIN_9
#define SR04_TRIG_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)  /* PB��ʱ��ʹ�� */

#define GTIM_TIM4_INT 						 TIM4
#define GTIM_TIM4_INT_IRQn 					 TIM4_IRQn
#define GTIM_TIM4_INT_IRQHandler 			 TIM4_IRQHandler
#define GTIM_TIM4_CH3               		 TIM_CHANNEL_3
#define GTIM_TIM4_INT_CLK_ENABLE() 			 do{ __HAL_RCC_TIM4_CLK_ENABLE(); }while(0)

/******************************************************************************************/
/* LED�˿ڶ��� */
#define SR04_TRIG_SET(x)   do{ x ? \
							HAL_GPIO_WritePin(SR04_TRIG_GPIO_PORT, SR04_TRIG_GPIO_PIN, GPIO_PIN_SET) : \
							HAL_GPIO_WritePin(SR04_TRIG_GPIO_PORT, SR04_TRIG_GPIO_PIN, GPIO_PIN_RESET); \
							}while(0)   

#define	SR04_ECHO_GET()		HAL_GPIO_ReadPin(SR04_ECH0_GPIO_PORT, SR04_ECH0_GPIO_PIN)							
							
/******************************************************************************************/
/* �ⲿ�ӿں���*/
void sr04_init(void);				/* SR04��ʼ�� */							
uint32_t SR04_GetDistance(void);	/* ��ȡSR04����ǰ������ľ��� */
void SR04_Test(void);				/* SR04���� */							
#endif
