#ifndef _IWDG_H
#define _IWDG_H
#include "./SYSTEM/sys/sys.h"

/******************************************************************************************/
/* �ⲿ�ӿں���*/
void iwdg_init(uint8_t prer, uint16_t rlr);			/* ��ʼ�� */
void iwdg_feed(void);								/* ι�� */	

#endif
