#ifndef _SPI_H
#define _SPI_H
#include "./SYSTEM/sys/sys.h"

/*********************************************************************************************************/
/* ���Ŷ��� */

/* CS */
#define SPI1_CS_GPIO_PORT                  GPIOB		
#define SPI1_CS_GPIO_PIN                   GPIO_PIN_9
#define SPI1_CS_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)  /* PC��ʱ��ʹ�� */
/* SCK */
#define SPI1_SCK_GPIO_PORT                 GPIOA		
#define SPI1_SCK_GPIO_PIN                  GPIO_PIN_5
#define SPI1_SCK_GPIO_CLK_ENABLE()         do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)  /* PC��ʱ��ʹ�� */
/* MISO */
#define SPI1_MISO_GPIO_PORT                GPIOA		
#define SPI1_MISO_GPIO_PIN                 GPIO_PIN_6
#define SPI1_MISO_GPIO_CLK_ENABLE()        do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)  /* PC��ʱ��ʹ�� */
/* MOSI */
#define SPI1_MOSI_GPIO_PORT                GPIOA		
#define SPI1_MOSI_GPIO_PIN                 GPIO_PIN_7
#define SPI1_MOSI_GPIO_CLK_ENABLE()        do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)  /* PC��ʱ��ʹ�� */

/* �����ź���״̬ */
#define SPI1_CS_SET(x)     do{ x ? \
							HAL_GPIO_WritePin(SPI1_CS_GPIO_PORT, SPI1_CS_GPIO_PIN, GPIO_PIN_SET) : \
							HAL_GPIO_WritePin(SPI1_CS_GPIO_PORT, SPI1_CS_GPIO_PIN, GPIO_PIN_RESET); \
							}while(0)      /* ����CS��ƽ */

#define SPI1_SCK_SET(x)    do{ x ? \
							HAL_GPIO_WritePin(SPI1_SCK_GPIO_PORT, SPI1_SCK_GPIO_PIN, GPIO_PIN_SET) : \
							HAL_GPIO_WritePin(SPI1_SCK_GPIO_PORT, SPI1_SCK_GPIO_PIN, GPIO_PIN_RESET); \
							}while(0)      /* ����SCK��ƽ */

#define SPI1_MOSI_SET(x)   do{ x ? \
							HAL_GPIO_WritePin(SPI1_MOSI_GPIO_PORT, SPI1_MOSI_GPIO_PIN, GPIO_PIN_SET) : \
							HAL_GPIO_WritePin(SPI1_MOSI_GPIO_PORT, SPI1_MOSI_GPIO_PIN, GPIO_PIN_RESET); \
							}while(0)      /* ����MOSI��ƽ */

/* ��ȡMISO�ź���״̬ */
#define	GET_SPI1_MISO()				HAL_GPIO_ReadPin(SPI1_MISO_GPIO_PORT,SPI1_MISO_GPIO_PIN)
	
#define SPI1_CLK_ENABLE()			do{ __HAL_RCC_SPI1_CLK_ENABLE(); }while(0)	/* SPI1ʱ��ʹ�� */


							
/**************************************************************************************************************/
/* �ӿں��� */
void SPI_Init(void);						/* SPI��ʼ�� */
void SPI_Start(void);						/* SPI��ʼ�ź� */
void SPI_Stop(void);						/* SPIֹͣ�ź� */	
uint8_t SPI_SwapByte(uint8_t ByteSend);		/* SPI����1�ֽ����� */
						
#endif
