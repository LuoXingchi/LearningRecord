#ifndef _IR_SENDER_H
#define _IR_SENDER_H
#include "./SYSTEM/sys/sys.h"


/******************************************************************************************/
/* ���� ���� */

#define IR_SENDER_GPIO_PORT                  GPIOA
#define IR_SENDER_GPIO_PIN                   GPIO_PIN_8
#define IR_SENDER_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0) 

#define GTIM_TIM1_PWM_CLK_ENABLE() 			 do{ __HAL_RCC_TIM1_CLK_ENABLE(); }while(0)

#define TIM1_PWM                        	 TIM1
#define TIM1_PWM_CH1                    	 TIM_CHANNEL_1

/******************************************************************************************/
/* �ⲿ�ӿں���*/
void ir_sender_init(void);							/* ���ⷢ���ʼ�� */
void IR_sender_Data(uint8_t Dev, uint8_t Data);		/* ���ⷢ������ */
void IR_sender_Test(void);							/* ���ⷢ����� */

#endif
