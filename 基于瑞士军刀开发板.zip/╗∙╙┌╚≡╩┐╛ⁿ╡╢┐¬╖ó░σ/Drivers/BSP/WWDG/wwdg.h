#ifndef _WWDG_H
#define _WWDG_H
#include "./SYSTEM/sys/sys.h"

/******************************************************************************************/
/* �ⲿ�ӿں���*/
void wwdg_init(uint8_t tr, uint8_t wr, uint32_t fprer);		/* ��ʼ�� */	

#endif
