#ifndef _LIGHT_SENSOR_H
#define _LIGHT_SENSOR_H
#include "./SYSTEM/sys/sys.h"


/******************************************************************************************/
/* ���� ���� */

#define LIGHT_SENSOR_GPIO_PORT                  GPIOA
#define LIGHT_SENSOR_GPIO_PIN                   GPIO_PIN_3
#define LIGHT_SENSOR_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)

#define LIGHT_ADC1                            	ADC1 
#define LIGHT_ADC1_CH3                        	ADC_CHANNEL_3     /* ͨ��Y,  0 <= Y <= 17 */ 
#define ADC1_CH3_CLK_ENABLE()           	    do{ __HAL_RCC_ADC1_CLK_ENABLE(); }while(0)

/******************************************************************************************/
/* �ⲿ�ӿں���*/
void light_sensor_init(void);						/* ����ģ���ʼ�� */
uint16_t LightSensor_Get(void);						/* ��ȡADCת����� */
uint16_t LightSensor_GetAverage(uint8_t times);		/* ��ȡ���ADCת�������ƽ��ֵ */


#endif
