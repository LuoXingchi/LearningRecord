#ifndef _DHT11_H
#define _DHT11D_H
#include "./SYSTEM/sys/sys.h"

/******************************************************************************************/
/* ���� ���� */

#define DHT11_GPIO_PORT                  GPIOA
#define DHT11_GPIO_PIN                   GPIO_PIN_1
#define DHT11_GPIO_CLK_ENABLE()          do{ __HAL_RCC_GPIOA_CLK_ENABLE(); }while(0)  /* PA��ʱ��ʹ�� */

/******************************************************************************************/
/* LED�˿ڶ��� */
#define DHT11_SET(x)   do{ x ? \
						HAL_GPIO_WritePin(DHT11_GPIO_PORT, DHT11_GPIO_PIN, GPIO_PIN_SET) : \
						HAL_GPIO_WritePin(DHT11_GPIO_PORT, DHT11_GPIO_PIN, GPIO_PIN_RESET); \
						}while(0)      /* ����DHT11���� */

#define	DHT11_GET()		HAL_GPIO_ReadPin(DHT11_GPIO_PORT, DHT11_GPIO_PIN)
/******************************************************************************************/
/* �ⲿ�ӿں���*/
void DHT11_Init(void);		/* DHT11��ʼ�� */
							/* ��ȡDHT11�ɼ�����ʪ������ */						
void DHT11_ReadData(uint8_t* hum_m,uint8_t* hum_n,uint8_t* tem_m,uint8_t* tem_n);
void DHT11_Test(void);		/* DHT11��ʪ�Ȳɼ����� */						
#endif
